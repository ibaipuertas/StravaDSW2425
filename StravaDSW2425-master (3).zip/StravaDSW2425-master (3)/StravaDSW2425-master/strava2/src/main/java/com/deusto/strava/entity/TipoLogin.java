package com.deusto.strava.entity;

public enum TipoLogin {
    GOOGLE, META , STRAVA
}