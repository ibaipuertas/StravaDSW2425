package com.deusto.strava.factory;

import com.deusto.strava.external.GoogleGateway;
import com.deusto.strava.external.IServiceGateway;

import serviceGateway.FacebookGateway;

public class FactoryUser {
    public static IServiceGateway createService(String what) throws IllegalArgumentException {
        switch (what.toLowerCase()) {
            case "google":
                return new GoogleGateway();
            case "facebook":
                return new FacebookGateway();
            default:
                throw new IllegalArgumentException("Service " + what + " is not supported");
        }
    }
}

