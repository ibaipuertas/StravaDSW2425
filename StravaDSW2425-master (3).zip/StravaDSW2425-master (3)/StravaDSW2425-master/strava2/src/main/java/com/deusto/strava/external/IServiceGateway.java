package com.deusto.strava.external;

public interface IServiceGateway {
	public boolean authenticate(String email, String password);
}
