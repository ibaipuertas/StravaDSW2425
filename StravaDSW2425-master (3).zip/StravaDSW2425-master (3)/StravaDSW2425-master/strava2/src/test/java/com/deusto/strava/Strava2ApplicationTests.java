package com.deusto.strava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Strava2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
